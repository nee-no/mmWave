Just a mmWave environment

